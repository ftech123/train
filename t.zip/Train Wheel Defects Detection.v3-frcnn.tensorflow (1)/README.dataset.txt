# Train Wheel Defects Detection > FRCNN
https://universe.roboflow.com/train-wheel-defect-detection/train-wheel-defects-detection-3z8cz

Provided by a Roboflow user
License: CC BY 4.0

